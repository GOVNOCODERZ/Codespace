﻿#include "complex.h"

// (a+bi) + (c+di) = (a+c) + (b+d)i
TComplex TComplex::operator +(const TComplex& _s) const
{
	// Создаём третий объект, вызвав конструктор с параметрами,
	// корому передаём результаты сложения отдельно действительной
	// и мнимой частей.
	// Созданный объект тут же возвращаем в качестве результата.
	return TComplex(m_real + _s.m_real, m_imaginary + _s.m_imaginary);
}

// (a+bi) * (c+di) = (ac-bd) + (bc+ad)i
TComplex TComplex::operator *(const TComplex& _s) const
{
	// Здесь можно было бы сделать так же, как в методе выше,
	// но кода больше, поэтому сначала создаём пустой объект
	// (используется конструктор по умолчанию),
	// а затем по-отдельности присваиваем полям нужные значения.
	TComplex res;
	res.m_real = (m_real * _s.m_real) - (m_imaginary * _s.m_imaginary);
	res.m_imaginary = (m_imaginary * _s.m_real) + (m_real * _s.m_imaginary);
	return res;
}

// Изменяем значения первого объекта (переданного по указателю this)
TComplex& TComplex::operator +=(const TComplex& _s)
{
	// Можно повторить код по новой...
	m_real += _s.m_real;
	m_imaginary += _s.m_imaginary;
	return *this;
}

TComplex& TComplex::operator *=(const TComplex& _s)
{
	// ...а можно использовать уже написанный.
	// Здесь сначала происходит выполнение части кода: *this * _s,
	// где создаётся новый объект, который присваивается объекту *this
	// Далее возвращается ссылка на объект *this.
	// Такой код допустим при отсутвтвии динамически выделяемой памяти
	// и одинаковости действий при a = a + b и a += b.
	return (*this = *this * _s);
}

// Методы для ввода и вывода данных
std::istream& TComplex::scan(std::istream& _in)
{
	// Проверяем, происходит ли ввод с клавиатуры. Для этого сравниваем 
	// адреса в памяти переданного потока _in и потока cin из iostream
	if (&_in == &std::cin)
	{
		// Если вводим с клавиатуры, то выводим строку-приглашение
		std::cout << "Ведите реальную и мнимую части числа: ";
	}
	_in >> m_real >> m_imaginary;
	return _in;
}

std::ostream& TComplex::print(std::ostream& _out) const
{
	_out << "(" << m_real << " + " << m_imaginary << "i)";
	return _out;
}

// Внутри перегрузки операций для ввода и вывода просто вызываем
// существующие методы для ввода данных и их вывода.
// Такой синтаксис предпочтителен, т.к. не нарушает инкапсуляцию
// и помагает в случае появления классов-наледников.
std::istream& operator >>(std::istream& _in, TComplex& _c)
{
	return _c.scan(_in);
}

std::ostream& operator <<(std::ostream& _out, const TComplex& _c)
{
	return _c.print(_out);
}