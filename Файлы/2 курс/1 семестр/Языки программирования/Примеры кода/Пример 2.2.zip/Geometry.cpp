#include "Geometry.h"

void Geometry::print(std::ostream& out) const
{
	out << name;
}

void Geometry::scan(std::istream& in)
{
	if (&in == &std::cin)
		std::cout << "������� �������� ������: ";
	in >> name;
}

std::string Geometry::getClassName() const
{
	return "Geometry";
}

std::ostream& operator<<(std::ostream& out, const Geometry& obj)
{
	obj.print(out);
	return out;
}

std::istream& operator>>(std::istream& in, Geometry& obj)
{
	obj.scan(in);
	return in;
}