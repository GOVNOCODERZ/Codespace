#pragma once
#include <iostream>

class Geometry
{
protected:
	std::string name;

public:
	virtual void print(std::ostream&) const;
	virtual void scan(std::istream&);

	virtual double getLength() const = 0;
	virtual double getArea() const = 0;

	virtual std::string getClassName() const;

	virtual Geometry* getCopy() const = 0;

	virtual ~Geometry() {}
};

std::ostream& operator<<(std::ostream&, const Geometry&);
std::istream& operator>>(std::istream&, Geometry&);