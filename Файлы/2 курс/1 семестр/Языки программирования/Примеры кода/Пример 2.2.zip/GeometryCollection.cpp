#include "GeometryCollection.h"
#include "Point.h"
#include "PolyLine.h"

using namespace std;

GeometryCollection::GeometryCollection(Geometry** _gc, size_t _size)
{
	size = _size;
	if (_gc != nullptr)
	{
		gc = new Geometry*[size];
		for (size_t i = 0; i < size; i++)
		{
			gc[i] = (*_gc[i]).getCopy();
		}
	}
	else
	{
		gc = _gc;
	}
}

GeometryCollection::GeometryCollection(const GeometryCollection& obj)
	: GeometryCollection(obj.gc, obj.size)
{}

GeometryCollection::GeometryCollection(GeometryCollection&& obj)
{
	swap(gc, obj.gc);
	swap(size, obj.size);
}

GeometryCollection::~GeometryCollection()
{
	clear();
}

GeometryCollection& GeometryCollection::operator=(GeometryCollection obj)
{
	swap(gc, obj.gc);
	swap(size, obj.size);
	return *this;
}

void GeometryCollection::clear()
{
	for (size_t i = 0; i < size; i++)
	{
		delete gc[i];
	}
	delete[] gc;

	gc = nullptr;
	size = 0;
}

void GeometryCollection::print(std::ostream& out) const
{
	out << size << endl;
	for (size_t i = 0; i < size; i++)
	{
		out << (*gc[i]) << endl;
	}
}

void GeometryCollection::scan(std::istream& in)
{
	if (&in == &cin)
		cout << "������� ���������� �����: ";
	size_t s;
	in >> s;
	Geometry** arr = new Geometry * [s];
	for (size_t i = 0; i < s; i++)
	{
		if (&in == &cin)
			cout << "������� ��� ������ (Point/PolyLine): ";
		string type;
		in >> type;
		if (type == "Point")
			arr[i] = new Point;
		else if (type == "PolyLine")
			arr[i] = new PolyLine;
		in >> (*arr[i]);
	}
	
	clear();
	gc = arr;
	size = s;
}

double GeometryCollection::getOverallLength() const
{
	double res = 0.0;
	for (size_t i = 0; i < size; i++)
	{
		res += gc[i]->getLength();
	}
	return res;
}
double GeometryCollection::getOverallArea() const
{
	double res = 0.0;
	for (size_t i = 0; i < size; i++)
	{
		res += gc[i]->getArea();
	}
	return res;
}

std::istream& operator>>(std::istream& in, GeometryCollection& obj)
{
	obj.scan(in);
	return in;
}

std::ostream& operator<<(std::ostream& out, const GeometryCollection& obj)
{
	obj.print(out);
	return out;
}