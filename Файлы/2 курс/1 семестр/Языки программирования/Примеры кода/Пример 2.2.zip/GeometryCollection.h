#pragma once
#include "Geometry.h"

class GeometryCollection
{
	Geometry** gc;
	size_t size;

public:
	GeometryCollection(Geometry** _gc = nullptr, size_t _size = 0);
	GeometryCollection(const GeometryCollection&);
	GeometryCollection(GeometryCollection&&);
	~GeometryCollection();
	GeometryCollection& operator=(GeometryCollection);

	void clear();

	void print(std::ostream&) const;
	void scan(std::istream&);

	double getOverallLength() const;
	double getOverallArea() const;
};

std::istream& operator>>(std::istream&, GeometryCollection&);
std::ostream& operator<<(std::ostream&, const GeometryCollection&);