#include "Point.h"

using namespace std;

void Point::print(std::ostream& out) const
{
	Geometry::print(out);
	out << " " << x << " " << y;
}

void Point::scan(std::istream& in)
{
	Geometry::scan(in);
	if (&in == &cin)
		cout << "������� ���������� �����: ";
	in >> x >> y;
}

double Point::getLength() const
{
	return 0.0;
}

double Point::getArea() const
{
	return 0.0;
}

std::string Point::getClassName() const
{
	return "Point";
}

Geometry* Point::getCopy() const
{
	return new Point(x, y);
}

double Point::getDistance(const Point& obj) const
{
	double dx = (x - obj.x) * (x - obj.x);
	double dy = (y - obj.y) * (y - obj.y);
	return sqrt(dx + dy);
}