#pragma once
#include "Geometry.h"

class Point :
    public Geometry
{
protected:
    double x;
    double y;

public:
	Point(double _x = 0.0, double _y = 0.0)
		: x(_x), y(_y)
	{}

	void print(std::ostream&) const override;
	void scan(std::istream&) override;

	double getLength() const override;
	double getArea() const override;

	std::string getClassName() const override;

	Geometry* getCopy() const override;

	double getDistance(const Point&) const;
};

