#include "PolyLine.h"

using namespace std;

PolyLine::PolyLine(Point* _line, size_t _size)
{
	size = _size;
	if (_line != nullptr)
	{
		line = new Point[size];
		for (size_t i = 0; i < size; i++)
		{
			line[i] = _line[i];
		}
	}
	else
	{
		line = _line;
	}
}

PolyLine::PolyLine(const PolyLine& obj)
	: PolyLine(obj.line, obj.size)
{}

PolyLine::PolyLine(PolyLine&& obj)
{
	swap(size, obj.size);
	swap(line, obj.line);
}

PolyLine::~PolyLine()
{
	delete[] line;
}

PolyLine& PolyLine::operator=(PolyLine obj)
{
	swap(size, obj.size);
	swap(line, obj.line);
	return *this;
}

void PolyLine::print(std::ostream& out) const
{
	Geometry::print(out);
	out << " " << size << endl;
	for (size_t i = 0; i < size; i++)
	{
		out << line[i] << ", ";
	}
}

void PolyLine::scan(std::istream& in)
{
	Geometry::scan(in);
	in >> size;
	Point* arr = new Point[size];
	for (size_t i = 0; i < size; i++)
	{
		in >> arr[i];
	}

	delete[] line;
	line = arr;
}

double PolyLine::getLength() const
{
	double res = 0.0;
	for (size_t i = 0; i < size-1; i++)
	{
		res += line[i].getDistance(line[i + 1]);
	}
	return res;
}

double PolyLine::getArea() const
{
	return 0.0;
}

std::string PolyLine::getClassName() const
{
	return "PolyLine";
}

Geometry* PolyLine::getCopy() const
{
	return new PolyLine(*this);
}