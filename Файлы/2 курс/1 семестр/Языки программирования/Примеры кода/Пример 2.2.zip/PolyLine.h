#pragma once
#include "Geometry.h"
#include "Point.h"

class PolyLine :
    public Geometry
{
protected:
	Point* line;
	size_t size;

public:
	PolyLine(Point* _line = nullptr, size_t _size = 0);
	PolyLine(const PolyLine&);
	PolyLine(PolyLine&&);
	~PolyLine();

	PolyLine& operator=(PolyLine);

	void print(std::ostream&) const override;
	void scan(std::istream&) override;

	double getLength() const override;
	double getArea() const override;

	std::string getClassName() const override;

	Geometry* getCopy() const override;
};

